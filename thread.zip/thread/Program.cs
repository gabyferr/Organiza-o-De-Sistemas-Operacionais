﻿using System;
using System.Threading;



namespace NewThred
{ 
class CriaThread
{
  
    static void Main(String[] args)
    {
        int i, n = 3;
        for (i = 1; i <= n; i++)
        {
            Loop loop = new Loop(i);
            Thread t = new Thread(loop.run);
            t.Start();
            Console.WriteLine($"Thread {i} criado");
        }
    }
}



class Loop 
{
    private int j;
    public Loop(int i)
{
    j = i;
}

    public void run()
{
    Random random = new Random();
    while (true)
    {
        Console.WriteLine($"Thread {j} executado");

        Thread.Sleep(random.Next(5000));
    }
}
}
}